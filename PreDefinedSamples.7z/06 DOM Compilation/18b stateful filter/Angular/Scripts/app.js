﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
    })
    .filter("x", function () {
        var fn = function (value) {

            console.log("x filter");
 
            return value + "X";
        }

        fn.$stateful = true;

        return fn;
    })
    .controller("HomeCtrl", function ($scope) {
        $scope.message = "Hello ";

        $scope.run = function () {
            //
            //  Don't do anything --> Exists to initiate digest cycle
            //
        }

        $scope.change = function () {
            $scope.message += "Y";
        }
    });

angular.module("MyApp", ["ngSanitize"])
    .filter("x", function () {
        var fn = function (value) {

            console.log("x filter");

            return value + "X";
        }

        fn.$stateful = true;

        return fn;
    });
