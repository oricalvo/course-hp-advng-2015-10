﻿

angular.module("MyApp", [])
    .config(function ($sceProvider) {
        $sceProvider.enabled(false);
    })
    .run(function ($interpolate, $rootElement) {
        var template = "{{name}}";

        var interpolateFn = $interpolate(template, undefined, "html");

        var context = {
            name: "<script>alert('Ooops ...XSS');</script>",
        };

        var str = interpolateFn(context);

        angular.element(".message").append(str);
    })
    .controller("HomeCtrl", function ($scope) {
        $scope.message = "<h1>XXX</h1>";
    });
