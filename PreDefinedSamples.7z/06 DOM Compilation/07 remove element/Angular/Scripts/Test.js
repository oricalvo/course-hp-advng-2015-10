﻿function byPriority(a, b) {
    var diff = b.priority - a.priority;
    if (diff !== 0) return diff;
    if (a.name !== b.name) return (a.name < b.name) ? -1 : 1;
    return a.index - b.index;
}
