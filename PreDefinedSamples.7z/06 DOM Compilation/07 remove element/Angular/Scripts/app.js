﻿

angular.module("MyApp", [])
    .config(function ($compileProvider) {
    })
    .run(function ($compile, $rootScope, $interpolate) {
    })
    .controller("HomeCtrl", function () {
    })
    .directive("dir1", function () {
        return {
            compile: function (element) {
                console.log("dir1: " + element[0].outerHTML);
                element.append("<h1>Directive 1</h1>");

                //element.remove();
            }
        };
    })
    .directive("dir2", function () {
        return {
            compile: function (element) {
                console.log("dir2: " + element[0].outerHTML);

                element.append("<h1>Directive 2</h1>");
            }
        };
    })
    .directive("dir3", function () {
        return {
            compile: function (element) {
                console.log("dir3: " + element[0].outerHTML);

                element.append("<h1>Directive 3</h1>");
            }
        };
    });

