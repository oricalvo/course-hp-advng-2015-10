﻿bindJQuery();

publishExternalAPI(angular);

jqLite(document).ready(function () {
    var injector = createInjector(modules, config.strictDi);

    injector.invoke(['$rootScope', '$rootElement', '$compile', '$injector',
       function bootstrapApply(scope, element, compile, injector) {
           scope.$apply(function () {
               element.data('$injector', injector);
               compile(element)(scope);
           });
       }]
    );

});
