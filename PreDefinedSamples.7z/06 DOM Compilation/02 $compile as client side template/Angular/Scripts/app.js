﻿

angular.module("MyApp", []).run(function ($compile, $rootScope, $interpolate) {
    var template = angular.element("<span>{{name}}</span>");
    console.log("Template: " + template[0].outerHTML);

    var templateFn = $compile(template);
    console.log("$compile: " + template[0].outerHTML);

    var scope = $rootScope.$new();
    templateFn(scope);
    console.log("link: " + template[0].outerHTML);

    scope.name = "App Data";
    scope.$digest();
    console.log("$digest: " + template[0].outerHTML);
});
