﻿function $interpolate(text) {
    var expressions = [], parseFns = [];

    while (index < textLength) {
        if (((startIndex = text.indexOf(startSymbol, index)) != -1) &&
             ((endIndex = text.indexOf(endSymbol, startIndex + startSymbolLength)) != -1)) {
            exp = extract expression between startIndex and endIndex
            expressions.push(exp);
            parseFns.push($parse(exp, parseStringifyInterceptor));
        } 
    }

    return function interpolationFn(context) {
        var values = new Array(ii);

        for (var i=0, ii=expressions.length; i < ii; i++) {
            values[i] = parseFns[i](context);
        }

        return compute(values);
    }
}
