﻿

angular.module("MyApp", [])
    .run(function ($interpolate) {
        var template = "Hello, {{name}}";

        var interpolateFn = $interpolate(template);

        var str = interpolateFn({ name: "Ori" });

        console.log(str);
    })
    .controller("HomeCtrl", function ($scope) {
    });
