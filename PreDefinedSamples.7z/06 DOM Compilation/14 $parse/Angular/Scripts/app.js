﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
        var expr = "ctrl.message";
        var compiledExpr = $parse(expr);

        var context = { ctrl: { message: "Hello $parse" } };
        var str = compiledExpr(context);

        console.log(str);
    })
    .controller("HomeCtrl", function ($scope) {
    });

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
        var expr = "ctrl.message";
        var compiledExpr = $parse(expr);

        var context = { ctrl: { message: "Hello $parse" } };
        var str = compiledExpr(context);

        console.log(str);
    });