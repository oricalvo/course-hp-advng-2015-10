﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
        var expr = "ctrl.contact = {'e-mail': email}";
        var compiledExpr = $parse(expr);

        console.log("assign: " + !!compiledExpr.assign);
        console.log("literal: " + !!compiledExpr.literal);
        console.log("constant: " + !!compiledExpr.constant);

        var context = {};
        var str = compiledExpr(context, { email: "ori@gmail.com" });

        console.log(str);
        console.log(context);
    })
    .controller("HomeCtrl", function ($scope) {
    });
