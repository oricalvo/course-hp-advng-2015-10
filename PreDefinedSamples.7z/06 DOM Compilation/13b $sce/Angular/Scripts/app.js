﻿

angular.module("MyApp", [])
//angular.module("MyApp", ["ngSanitize"])
    .config(function ($sceProvider) {
        //$sceProvider.enabled(false);
    })
    .run(function ($interpolate, $rootElement, $parse, $sce) {

        //var value = "<script>alert('XSS')</script>";
        var value = "<h1>CSE</h1>";

        //
        //  Try below code with/without ngSanitize
        //
        try {
            console.log("$sce.getTrusted: " + $sce.getTrusted($sce.HTML, value));
        }
        catch (err) {
            console.log("$sce.getTrusted failed: " + err.message);
        }

        try {
            var parseFn = $sce.parseAs($sce.HTML, "name");
            var str = parseFn({ name: value });
            console.log("$sce.parseAs: " + str);
        }
        catch (err) {
            console.log("$sce.parseAs failed: " + err.message);
        }

    })
    .controller("HomeCtrl", function ($scope) {
        $scope.message = "<h1>XXX</h1>";
    });
