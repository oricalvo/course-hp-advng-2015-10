﻿function addTextInterpolateDirective(directives, text) {
    var interpolateFn = $interpolate(text, true);
    if (interpolateFn) {
        directives.push({
            priority: 0,
            compile: function textInterpolateCompileFn(templateNode) {
                return function textInterpolateLinkFn(scope, node) {
                    scope.$watch(interpolateFn, function interpolateFnWatchAction(value) {
                        node[0].nodeValue = value;
                    });
                };
            }
        });
    }
}
