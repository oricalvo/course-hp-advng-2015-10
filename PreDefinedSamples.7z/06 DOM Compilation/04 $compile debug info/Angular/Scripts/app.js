﻿

angular.module("MyApp", [])
    .config(function ($compileProvider) {
        //$compileProvider.debugInfoEnabled(false);
    })
    .run(function ($compile, $rootScope, $interpolate) {
        var template = angular.element(angular.element("script[type='text/x-ng-course']").html());
        console.log("Template: " + template[0].outerHTML);

        var templateFn = $compile(template);
        console.log("$compile: " + template[0].outerHTML);

        for (var i = 0; i < 10; i++) {
            var scope = $rootScope.$new();
            scope.message = "My Data " + (i + 1);

            var view = templateFn(scope, function (clone) {
            });

            scope.$digest();
            console.log("view " + (i + 1) + ": " + view[0].outerHTML);
        }

        console.log("Template: " + template[0].outerHTML);
    })
    .controller("HomeCtrl", function () {
    });

