﻿(function () {

    function HomeCtrl($scope, $compile, $rootScope) {
        $scope.message = "Hello Angular";

        $scope.run = function () {
            var template = angular.element("<span>{{name}}</span>");
            console.log(template[0].outerHTML);

            var linkFn = $compile(template);
            console.log(template[0].outerHTML);

            var scope = $rootScope.$new();
            scope.name = "Ori";
            linkFn(scope);
            console.log(template[0].outerHTML);

            scope.$applyAsync();

            scope.$$postDigest(function () {
                console.log(template[0].outerHTML);
            });
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
