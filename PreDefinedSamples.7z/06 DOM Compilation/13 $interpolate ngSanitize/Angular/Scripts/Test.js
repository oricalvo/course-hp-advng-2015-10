﻿function $interpolate(text, mustHaveExpression, trustedContext) {
    ...

    while (index < textLength) {
        ...
        parseFns.push($parse(exp, parseStringifyInterceptor));
    }

    var getValue = function (value) {
        return trustedContext ?
          $sce.getTrusted(trustedContext, value) :
          $sce.valueOf(value);
    };

    function parseStringifyInterceptor(value) {
        ...
        return value = getValue(value);
    }
}
