﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($interpolate, $rootElement, $sce) {
        var template = "{{name}}";

        var interpolateFn = $interpolate(template, undefined, $sce.HTML);

        var context = {
            name: "<h1>Hello</h1>"
        };

        var str = interpolateFn(context);

        angular.element(".message").append(str);
    })
    .controller("HomeCtrl", function ($scope) {
    });
