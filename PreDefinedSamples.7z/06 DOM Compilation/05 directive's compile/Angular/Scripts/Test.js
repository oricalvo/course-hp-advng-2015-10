﻿function directive(name, directiveFactory) {

    if (!hasDirectives.hasOwnProperty(name)) {
        hasDirectives[name] = [];
        $provide.factory(name + 'Directive', ['$injector', '$exceptionHandler',
            function ($injector, $exceptionHandler) {
                var directives = [];

                forEach(hasDirectives[name], function (directiveFactory, index) {
                    var directive = $injector.invoke(directiveFactory);

                    if (isFunction(directive)) {
                        directive = { compile: valueFn(directive) };
                    } else if (!directive.compile && directive.link) {
                        directive.compile = valueFn(directive.link);
                    }

                    directive.priority = directive.priority || 0;
                    directive.index = index;
                    directive.name = directive.name || name;
                    directive.require = directive.require || (directive.controller && directive.name);
                    directive.restrict = directive.restrict || 'EA';
                    if (isObject(directive.scope)) {
                        directive.$$isolateBindings = parseIsolateBindings(directive.scope, directive.name);
                    }
                    directives.push(directive);
                });

                return directives;
            }]);
    }

    hasDirectives[name].push(directiveFactory);

    return this;
};
