﻿

angular.module("MyApp", [])
    .config(function ($compileProvider) {
    })
    .run(function ($compile, $rootScope, $interpolate) {
    })
    .controller("HomeCtrl", function () {
    })
    .directive("my", function () {
        return {
            compile: function () {
                console.log("my");
            }
        };
    });

