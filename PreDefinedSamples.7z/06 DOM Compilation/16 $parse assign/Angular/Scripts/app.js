﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
var expr = "ctrl.contact";
var getter = $parse(expr);
var setter = getter.assign;

var context = {};
if (setter) {
    setter(context, { name: "Ori" });
}

console.log(context);
    })
    .controller("HomeCtrl", function ($scope) {
    });
