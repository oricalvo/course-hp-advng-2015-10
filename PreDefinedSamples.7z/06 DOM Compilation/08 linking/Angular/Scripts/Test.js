﻿function nodeLinkFn(childLinkFn, scope, ...) {
    if (newIsolateScopeDirective) {
        isolateScope = scope.$new(true);
    }

    // PRELINKING
    for (i = 0, ii = preLinkFns.length; i < ii; i++) {
        linkFn = preLinkFns[i];
        invokeLinkFn(linkFn, ...);
    }

    // RECURSIVE
    childLinkFn && childLinkFn(scopeToChild, linkNode.childNodes, undefined, boundTranscludeFn);

    // POSTLINKING
    for (i = postLinkFns.length - 1; i >= 0; i--) {
        linkFn = postLinkFns[i];
        invokeLinkFn(linkFn, ...);
    }
}
