﻿

angular.module("MyApp", [])
    .config(function ($compileProvider) {
    })
    .run(function ($compile, $rootScope, $interpolate) {

        var template = angular.element("<parent><child></child></parent>");

        var scope = $rootScope.$new();

        $compile(template)(scope);
    })
    .controller("HomeCtrl", function () {
    })
    .directive("parent", function () {
        return {
            compile: function () {
                console.log("parent:compile");

                return {
                    pre: function () {
                        console.log("parent:preLink");
                    },
                    post: function () {
                        console.log("parent:postLink");
                    }
                };
            },
            controller: function () {
                console.log("parent:controller");
            },
            //template: function () {
            //    console.log("parent:template");

            //    return "<span>Parent</span>";
            //}
        };
    })
    .directive("child", function () {
        return {
            compile: function () {
                console.log("child:compile");

                return {
                    pre: function () {
                        console.log("child:preLink");
                    },
                    post: function () {
                        console.log("child:postLink");
                    }
                };
            },
            controller: function () {
                console.log("child:controller");
            },
            template: function () {
                console.log("child:template");

                return "<span>Child</span>";
            }
        };
    });
