﻿

angular.module("MyApp", [])
    .config(function ($compileProvider) {
    })
    .run(function ($compile, $rootScope, $interpolate) {
    })
    .controller("HomeCtrl", function () {
    })
    .directive("my", function () {
        return {
            compile: function (element) {
                console.log("my #1: " + element.html());
                element.append("<h1>Compile 1</h1>");
            }
        };
    })
    .directive("my", function () {
        return {
            //priority: 1,
            compile: function (element) {
                console.log("my #2: " + element.html());
                element.append("<h1>Compile 2</h1>");
            }
        };
    });

