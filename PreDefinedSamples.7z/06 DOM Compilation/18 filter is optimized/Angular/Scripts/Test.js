﻿function $parse(exp, interceptorFn, expensiveChecks) {
    var parsedExpression, oneTime, cacheKey;

    switch (typeof exp) {
        case 'string':
            var lexer = new Lexer(...);
            var parser = new Parser(lexer, $filter, ...);
            parsedExpression = parser.parse(exp);

            return addInterceptor(parsedExpression, interceptorFn);

        case 'function':
            return addInterceptor(exp, interceptorFn);

        default:
            return addInterceptor(noop, interceptorFn);
    }
};
