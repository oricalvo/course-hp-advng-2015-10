﻿

angular.module("MyApp", ["ngSanitize"])
    .run(function ($parse) {
    })
    .controller("HomeCtrl", function ($scope) {
        $scope.when = new Date();

        $scope.run = function () {
            //
            //  Don't do anything --> Exists to initiate digest cycle
            //
        }

        $scope.change = function () {
            $scope.when = new Date();
        }
    });
