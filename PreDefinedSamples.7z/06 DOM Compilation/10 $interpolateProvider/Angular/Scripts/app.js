﻿

angular.module("MyApp", [])
    .config(function ($interpolateProvider) {
        $interpolateProvider.startSymbol("<%");
        $interpolateProvider.endSymbol("%>");
    })
    .run(function () {
    })
    .controller("HomeCtrl", function ($scope) {
        $scope.message = "Hello $interpolateProvider";
    });
