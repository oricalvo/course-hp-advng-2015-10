﻿/// <reference path="angular.js" />

(function () {

    function ClockDirectiveController($scope) {
    }

angular.module("MyApp").directive("clock", function () {
    return {
        controller: ClockDirectiveController,
        templateUrl: "/Home/Clock",
        bindToController: true,
        controllerAs: "ctrl",
        scope: {
            time: "=",
        },
    };
});

})();
