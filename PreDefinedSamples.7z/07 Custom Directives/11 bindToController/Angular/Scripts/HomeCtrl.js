﻿(function () {

function HomeCtrl($scope, $interval) {
    $interval(function () {
        $scope.time = new Date();
    }, 1000);
}

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);

})();
