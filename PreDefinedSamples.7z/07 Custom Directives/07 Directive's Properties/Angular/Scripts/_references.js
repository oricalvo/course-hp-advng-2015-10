﻿/// <autosync enabled="true" />
/// <reference path="test.js" />
/// <reference path="angular.js" />
/// <reference path="homectrl.js" />
/// <reference path="app.js" />
/// <reference path="clockdirective.js" />

