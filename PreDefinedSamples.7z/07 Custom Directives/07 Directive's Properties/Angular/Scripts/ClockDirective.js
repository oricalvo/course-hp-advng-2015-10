﻿/// <reference path="angular.js" />

(function () {

function ClockDirectiveController($scope, $parse, $attrs) {
    if ($attrs.time) {
        $scope.$parent.$watch($attrs.time, function (newValue) {
            $scope.time = newValue;
        });
    }
}

    angular.module("MyApp").directive("clock", function () {
        return {
            controller: ClockDirectiveController,
            templateUrl: "/Home/Clock",
            scope: {
                tick: "&ontick",
            },
        };
    });

})();
