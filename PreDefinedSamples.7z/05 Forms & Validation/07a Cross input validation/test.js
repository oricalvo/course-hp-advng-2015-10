﻿var ngModelDirective = ['$rootScope', function ($rootScope) {
    return {
        compile: function ngModelCompile(element) {
            return {
                pre: function ngModelPreLink(scope, element, attr, ctrls) {
                    var modelCtrl = ctrls[0],
                        formCtrl = ctrls[1] || nullFormCtrl;

                    modelCtrl.$$setOptions(ctrls[2] && ctrls[2].$options);

                    // notify others, especially parent forms
                    formCtrl.$addControl(modelCtrl);

                    attr.$observe('name', function (newValue) {
                        if (modelCtrl.$name !== newValue) {
                            formCtrl.$$renameControl(modelCtrl, newValue);
                        }
                    });

                    scope.$on('$destroy', function () {
                        formCtrl.$removeControl(modelCtrl);
                    });
                },
                post: function ngModelPostLink(scope, element, attr, ctrls) {
                    var modelCtrl = ctrls[0];
                    if (modelCtrl.$options && modelCtrl.$options.updateOn) {
                        element.on(modelCtrl.$options.updateOn, function (ev) {
                            modelCtrl.$$debounceViewValueCommit(ev && ev.type);
                        });
                    }

                    element.on('blur', function (ev) {
                        if (modelCtrl.$touched) return;

                        if ($rootScope.$$phase) {
                            scope.$evalAsync(modelCtrl.$setTouched);
                        } else {
                            scope.$apply(modelCtrl.$setTouched);
                        }
                    });
                }
            };
        }
    };
}];
