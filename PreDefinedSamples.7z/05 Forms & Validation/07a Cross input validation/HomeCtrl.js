﻿(function () {

    function HomeCtrl($scope) {

        $scope.$watch(function () {
            var num1 = $scope.num1 * 1;
            var num2 = $scope.num2 * 1;
            var valid = num1 && num2 && num1 < num2;
            $scope.form.$setValidity("num1IsGreaterThanNum2", valid);
        });

        $scope.save = function () {
            if ($scope.form.$invalid) {
                return;
            }

            console.log("Saving");
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
