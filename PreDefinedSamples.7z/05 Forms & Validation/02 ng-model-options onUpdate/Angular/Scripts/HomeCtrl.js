﻿(function () {

    function HomeCtrl($scope, $rootScope, $compile) {
    }

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);

})();
