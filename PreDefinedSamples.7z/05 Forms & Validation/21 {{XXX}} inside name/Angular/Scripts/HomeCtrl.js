﻿(function () {

    function HomeCtrl($scope, $rootScope, $compile) {
        $scope.field = "name";

        $scope.save = function () {

            console.log("form.name.$invalid: " + $scope.form.name.$invalid);

            if ($scope.form.$invalid) {
                return;
            }

            console.log("Saving ...");
        }
    }

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);

})();
