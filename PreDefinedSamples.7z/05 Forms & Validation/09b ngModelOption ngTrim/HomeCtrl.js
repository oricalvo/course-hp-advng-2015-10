﻿(function () {

function HomeCtrl($scope) {
    $scope.save = function () {
        console.log("name: '" + $scope.name + "'");
    }
}

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
