﻿(function () {

    function HomeCtrl($scope, $rootScope, $compile) {
        $scope.save = function () {
            if ($scope.form.$invalid) {
                return;
            }

            console.log("Saving ...");
        }
    }

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);

})();
