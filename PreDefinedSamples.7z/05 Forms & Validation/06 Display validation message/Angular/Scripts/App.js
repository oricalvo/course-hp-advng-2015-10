﻿angular.module("MyApp", []);

