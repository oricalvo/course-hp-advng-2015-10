﻿(function () {

    function HomeCtrl($scope, $rootScope, $compile) {
        $scope.num = 13;

        $scope.save = function () {
            if ($scope.form.$invalid) {
                console.log("Not valid");
                console.log("    num: " + $scope.num);

                return;
            }

            console.log("Saving ...");
            console.log("    num: " + $scope.num);
        }
    }

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);
})();
