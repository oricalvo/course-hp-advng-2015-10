﻿angular.module("MyApp", []).directive('integer', function () {

    console.log("integer");

    return {
        restrict: "A",
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
            console.log("integer: link");
            //console.log("    ctrl.$valid: " + ctrl.$valid);

            //ctrl.$parsers.push(function (value) {
            //    console.log("integer: parsing '" + value + "'");
            //    //console.log("    ctrl.$valid: " + ctrl.$valid);

            //    if (value == 12) {
            //        return 12;
            //    }

            //    return undefined;
            //});

            ctrl.$validators.integer = function (modelValue, viewValue) {
                if (modelValue == 12) {
                    return true;
                }

                return false;
            }

            //// view -> model
            //elm.on('blur', function () {
            //    scope.$apply(function () {
            //        ctrl.$setViewValue(elm.html());
            //    });
            //});

            //// model -> view
            //ctrl.$render = function () {
            //    elm.html(ctrl.$viewValue);
            //};

            //// load init value from DOM
            //ctrl.$setViewValue(elm.html());
        }
    };
});