﻿var ngModelDirective = ['$rootScope', function ($rootScope) {
    return {
        restrict: 'A',
        require: ['ngModel', '^?form', '^?ngModelOptions'],
        controller: NgModelController,
        priority: 1,
        compile: function ngModelCompile(element) {
            element.addClass(PRISTINE_CLASS).addClass(UNTOUCHED_CLASS).addClass(VALID_CLASS);

            return {
                pre: function ngModelPreLink(scope, element, attr, ctrls) {
                    var modelCtrl = ctrls[0], formCtrl = ctrls[1] || nullFormCtrl;

                    modelCtrl.$$setOptions(ctrls[2] && ctrls[2].$options);

                    formCtrl.$addControl(modelCtrl);

                    scope.$on('$destroy', function () {
                        formCtrl.$removeControl(modelCtrl);
                    });
                },
                post: function ngModelPostLink(scope, element, attr, ctrls) {
                    var modelCtrl = ctrls[0];

                    if (modelCtrl.$options && modelCtrl.$options.updateOn) {
                        element.on(modelCtrl.$options.updateOn, function (ev) {
                            modelCtrl.$$debounceViewValueCommit(ev && ev.type);
                        });
                    }

                    element.on('blur', function (ev) {
                        ...
                        scope.$apply(modelCtrl.$setTouched);
                    });
                }
            };
        }
    };
}];
