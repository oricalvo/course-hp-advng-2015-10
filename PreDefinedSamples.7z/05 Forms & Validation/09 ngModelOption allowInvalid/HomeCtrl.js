﻿(function () {

    function HomeCtrl($scope) {
        $scope.email = "";

        $scope.save = function () {
            console.log("email: " + $scope.email);
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
