﻿(function () {

function HomeCtrl($scope) {
    $scope.save = function () {
        console.log("formMain.$valid: " + $scope.formMain.$valid);
        console.log("formChild.$valid: " + $scope.formMain.formChild.$valid);
    }
}

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
