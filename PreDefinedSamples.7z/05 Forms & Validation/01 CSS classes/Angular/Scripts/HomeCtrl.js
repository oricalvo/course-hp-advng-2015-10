﻿(function () {

    function HomeCtrl($scope) {
    }

    angular.module("MyApp")
        .controller("HomeCtrl", HomeCtrl);

})();
