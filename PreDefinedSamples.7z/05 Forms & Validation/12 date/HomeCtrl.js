﻿(function () {

    function HomeCtrl($scope) {
        $scope.change = function () {
            $scope.date = new Date();
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
