﻿(function () {

angular.module("MyApp").directive("date", DatepickerDirective);
function DatepickerDirective() {
    return {
        require: ["?ngModel"],
        restrict: "A",
        link: function (scope, element, attrs, ctrls) {
            var ctrl = ctrls[0];
            if (!ctrl) {
                return;
            }

            ctrl.$validators.date = function (value) {
                if (value == undefined) {
                    return true;
                }

                var res = moment(value, "D/M/YY", true).isValid();
                return res;
            }
        }
    };
}

})();
