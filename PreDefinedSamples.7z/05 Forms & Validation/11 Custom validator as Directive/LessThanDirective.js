﻿(function () {

function LessThanDirective() {
    return {
        require: ["?ngModel"],
        link: function (scope, element, attrs, ctrls) {
            var ctrl = ctrls[0];
            if (!ctrl) {
                return;
            }

            attrs.$observe("lessThan", function () {
                ctrl.$validate();
            });

            ctrl.$validators.lessThan = function (value) {
                var res = !value || value < attrs.lessThan;
                return res;
            }
        }
    };
}

angular.module("MyApp").directive("lessThan", LessThanDirective);

})();
