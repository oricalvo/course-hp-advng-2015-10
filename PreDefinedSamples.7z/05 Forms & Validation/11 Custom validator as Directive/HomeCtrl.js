﻿(function () {

    function HomeCtrl($scope) {
        $scope.max = 10;

        $scope.change = function () {
            $scope.max *= 2;

            console.log("max = " + $scope.max);
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
