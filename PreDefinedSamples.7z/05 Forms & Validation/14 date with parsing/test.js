﻿this.$$parseAndValidate = function () {
    var viewValue = ctrl.$$lastCommittedViewValue;
    var modelValue = viewValue;

    for (var i = 0; i < ctrl.$parsers.length; i++) {
        modelValue = ctrl.$parsers[i](modelValue);
        if (isUndefined(modelValue)) {
            parserValid = false;
            break;
        }
    }

    if (allowInvalid) {
        ctrl.$modelValue = modelValue;
        writeToModelIfNeeded();
    }

    ctrl.$$runValidators(modelValue, ctrl.$$lastCommittedViewValue, function (allValid) {
    });
};
