﻿(function () {

    function HomeCtrl($scope) {
        $scope.change = function () {
            $scope.date = new Date();
        }

        $scope.dump = function () {
            console.log("date: " + $scope.date);
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
