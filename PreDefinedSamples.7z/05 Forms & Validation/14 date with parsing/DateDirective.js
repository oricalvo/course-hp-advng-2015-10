﻿(function () {

    angular.module("MyApp").directive("date", DatepickerDirective);
    function DatepickerDirective() {
        return {
            require: ["?ngModel"],
            restrict: "A",
            link: function (scope, element, attrs, ctrls) {
                var ctrl = ctrls[0];
                if (!ctrl) {
                    return;
                }

                ctrl.$validators.date = function (value) {
                    if (value == undefined || (value instanceof Date)) {
                        return true;
                    }

                    var res = moment(value, "D/M/YY", true).isValid();
                    return res;
                }

                ctrl.$formatters.push(function (value) {
                    if (value instanceof Date) {
                        return moment(value).format("D/M/YY");
                    }

                    return value;
                });

                ctrl.$parsers.push(function (value) {
                    var date = moment(value, "D/M/YY", true);
                    if (!date.isValid()) {
                        return undefined;
                    }

                    return date.toDate();
                });
            }
        };
    }

})();
