﻿(function () {

function HomeCtrl($scope) {
    $scope.$evalAsync(function () {
        $scope.form.num.$validators.lessThan = function (value) {
            if (value == undefined) {
                return true;
            }

            var res = value < 10;
            return res;
        }
    });
}

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
