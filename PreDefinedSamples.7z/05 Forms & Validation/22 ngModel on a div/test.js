﻿this.$setViewValue = function (value, trigger) {
    ctrl.$viewValue = value;
    if (!ctrl.$options || ctrl.$options.updateOnDefault) {
        $scope.$apply(function () {
            ctrl.$commitViewValue();
        });
    }
};

this.$commitViewValue = function () {
    var viewValue = ctrl.$viewValue;

    if (ctrl.$$lastCommittedViewValue === viewValue && (viewValue !== '' || !ctrl.$$hasNativeValidators)) {
        return;
    }

    ctrl.$$lastCommittedViewValue = viewValue;

    // change to dirty
    if (ctrl.$pristine) {
        this.$setDirty();
    }

    this.$$parseAndValidate();
};

this.$$parseAndValidate = function () {
    var viewValue = ctrl.$$lastCommittedViewValue;
    var modelValue = viewValue;
    parserValid = isUndefined(modelValue) ? undefined : true;

    if (parserValid) {
        for (var i = 0; i < ctrl.$parsers.length; i++) {
            modelValue = ctrl.$parsers[i](modelValue);
            if (isUndefined(modelValue)) {
                parserValid = false;
                break;
            }
        }
    }
    if (isNumber(ctrl.$modelValue) && isNaN(ctrl.$modelValue)) {
        // ctrl.$modelValue has not been touched yet...
        ctrl.$modelValue = ngModelGet($scope);
    }
    var prevModelValue = ctrl.$modelValue;
    var allowInvalid = ctrl.$options && ctrl.$options.allowInvalid;
    ctrl.$$rawModelValue = modelValue;

    if (allowInvalid) {
        ctrl.$modelValue = modelValue;
        writeToModelIfNeeded();
    }

    // Pass the $$lastCommittedViewValue here, because the cached viewValue might be out of date.
    // This can happen if e.g. $setViewValue is called from inside a parser
    ctrl.$$runValidators(modelValue, ctrl.$$lastCommittedViewValue, function (allValid) {
        if (!allowInvalid) {
            // Note: Don't check ctrl.$valid here, as we could have
            // external validators (e.g. calculated on the server),
            // that just call $setValidity and need the model value
            // to calculate their validity.
            ctrl.$modelValue = allValid ? modelValue : undefined;
            writeToModelIfNeeded();
        }
    });

    function writeToModelIfNeeded() {
        if (ctrl.$modelValue !== prevModelValue) {
            ctrl.$$writeModelToScope();
        }
    }
};
