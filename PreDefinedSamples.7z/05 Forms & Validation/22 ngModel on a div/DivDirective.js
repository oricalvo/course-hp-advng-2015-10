﻿angular.module("MyApp").directive("div", function () {
    var ddo = {
        require: ["?ngModel"],
        link: function (scope, element, attrs, ctrls) {
            var ngModelCtrl = ctrls[0];
            var duringRender = false;

            if (!ngModelCtrl) {
                return;
            }

            console.log("Div: link");
            console.log("    ctrls.length: " + ctrls.length);

            element.on("DOMSubtreeModified", function (ev) {
                if (duringRender) {
                    return;
                }

                var viewValue = element.text();
                if (viewValue == ngModelCtrl.$viewValue) {
                    return;
                }

                console.log("DOM changed");

                ngModelCtrl.$setViewValue(viewValue, ev.type)
            });

            ngModelCtrl.$render = function () {
                duringRender = true;

                try {
                    element.text(ngModelCtrl.$viewValue);
                }
                finally {
                    duringRender = false;
                }
            }

            //element.text(ngModelCtrl.$viewValue);
        }
    };

    return ddo;
});
