﻿(function () {

    function HomeCtrl($scope, $element) {
        $scope.message = "";

        $scope.changeDOM = function () {
            $element.find("div[ng-model]")[0].innerHTML = "123";
        }

        $scope.changeScope = function () {
            $scope.message += "X";
        }

        $scope.dump = function () {
            console.log("message = " + $scope.message);
        }
    }

    angular.module("MyApp").controller("HomeCtrl", HomeCtrl);
})();
