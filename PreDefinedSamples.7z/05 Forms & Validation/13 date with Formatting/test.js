﻿function DatepickerDirective() {
    return {
        require: ["?ngModel"],
        restrict: "A",
        link: function (scope, element, attrs, ctrls) {
            ctrl.$formatters.push(function (value) {
                if (value instanceof Date) {
                    return moment(value).format("D/M/YY");
                }

                return value;
            });
        }
    };
}

$scope.$watch(function ngModelWatch() {
    var modelValue = ngModelGet($scope);

    if (modelValue !== ctrl.$modelValue) {
        var viewValue = modelValue;
        while (idx--) {
            viewValue = formatters[idx](viewValue);
        }
    }

    return modelValue;
});
