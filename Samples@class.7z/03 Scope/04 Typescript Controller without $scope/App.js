﻿(function () {

    angular.module("MyApp", []).run(function () {
    });

})();
