﻿(function () {

    angular.module("MyApp", []);

})();
