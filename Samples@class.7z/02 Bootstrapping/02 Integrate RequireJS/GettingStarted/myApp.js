﻿define(["angular", "jquery"], function () {
    angular.module("myApp", []);
});
