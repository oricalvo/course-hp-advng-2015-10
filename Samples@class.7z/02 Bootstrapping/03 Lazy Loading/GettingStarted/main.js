﻿define(["HomeCtrl"], function () {
    angular.bootstrap($("html"), ["myApp"]);
});
