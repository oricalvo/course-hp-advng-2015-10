var Point = (function () {
    function Point() {
    }
    return Point;
})();
