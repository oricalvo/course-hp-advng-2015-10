class Point {
}
