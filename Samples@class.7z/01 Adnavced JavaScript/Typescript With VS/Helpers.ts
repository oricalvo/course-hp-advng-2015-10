﻿export function doSomething() {
    console.log("doSomething");
}

function run() {
}
 