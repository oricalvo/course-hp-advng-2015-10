function doSomething() {
    console.log("doSomething");
}
exports.doSomething = doSomething;
function run() {
}
//# sourceMappingURL=Helpers.js.map