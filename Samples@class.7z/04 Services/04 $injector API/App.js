﻿(function () {

    angular.module("MyApp", []);
})();
